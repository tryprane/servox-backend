# Servox VPS Quickstart Guide

Welcome to your new Servox VPS! This guide will help you get started with your server.

## First Steps

1. **Update your system packages**:
   ```bash
   sudo apt update && sudo apt upgrade -y
   ```


